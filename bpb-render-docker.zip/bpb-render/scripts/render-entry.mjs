import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { randomUUID, randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';

const root = new URL('..', import.meta.url).pathname;
const distFile = `${root}dist/worker.js`;
const dataDir = process.env.DATA_DIR || '/data';
const port = Number(process.env.PORT || 10000);
const tmpDir = process.env.TMPDIR || '/var/tmp';
const runtimeDir = process.env.RUNTIME_DIR || '/var/tmp/bpb-render-runtime';
const workerFile = `${runtimeDir}/bpb-worker.js`;
const wranglerFile = `${runtimeDir}/wrangler.jsonc`;

if (!existsSync(distFile)) {
  throw new Error(`Built worker not found at ${distFile}`);
}

mkdirSync(dataDir, { recursive: true });
mkdirSync(tmpDir, { recursive: true });
mkdirSync(runtimeDir, { recursive: true });

const csv = (value, fallback = []) => {
  if (!value) return fallback;
  return value.split(',').map((item) => item.trim()).filter(Boolean);
};

const isUuid = (value) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value || '');

const settings = {
  accID: process.env.CF_ACCOUNT_ID || '',
  accEmail: (process.env.CF_ACCOUNT_EMAIL || 'render@localhost').toLowerCase(),
  apiToken: process.env.CF_API_TOKEN || '',
  vlUUID: isUuid(process.env.VL_UUID) ? process.env.VL_UUID : randomUUID(),
  trPass: process.env.TR_PASS || randomBytes(18).toString('base64url'),
  securePath: process.env.SECURE_PATH || randomBytes(16).toString('hex'),
  proxyIpMode: process.env.PROXY_IP_MODE || 'proxyip',
  proxyIPs: csv(process.env.PROXY_IPS, ['bpb.yousef.isegaro.com']),
  prefixes: csv(process.env.PROXY_PREFIXES, ['[2a02:898:146:64::]', '[2602:fc59:b0:64::]', '[2602:fc59:11:64::]']),
  mainDomain: process.env.MAIN_DOMAIN || '',
  fallback: process.env.FALLBACK || '',
  dohUrl: process.env.DOH_URL || 'https://cloudflare-dns.com/dns-query'
};

let worker = readFileSync(distFile, 'utf8');
const injection = `Object.assign(globalThis, { EMBEDED_SETTINGS: ${JSON.stringify(settings)} });\n`;
if (!worker.startsWith('Object.assign(globalThis, { EMBEDED_SETTINGS:')) {
  worker = injection + worker;
}
writeFileSync(workerFile, worker, 'utf8');

const wrangler = {
  name: 'bpb-render',
  main: workerFile,
  compatibility_date: '2026-06-03',
  compatibility_flags: ['nodejs_compat'],
  no_bundle: true,
  kv_namespaces: [{ binding: 'kv', id: 'bpb-render-kv', preview_id: 'bpb-render-kv' }]
};
writeFileSync(wranglerFile, JSON.stringify(wrangler, null, 2));

const child = spawn('npx', [
  '--yes', 'wrangler@4', 'dev',
  '--config', wranglerFile,
  '--local',
  '--ip', '0.0.0.0',
  '--port', String(port),
  '--persist-to', dataDir,
  '--show-interactive-dev-session', 'false'
], {
  stdio: 'inherit',
  env: { ...process.env, TMPDIR: tmpDir, NODE_DISABLE_COMPILE_CACHE: '1' }
});

child.on('exit', (code, signal) => {
  if (signal) process.kill(process.pid, signal);
  process.exit(code ?? 1);
});
